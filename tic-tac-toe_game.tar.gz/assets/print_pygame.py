import pygame

import functions

WIDTH, HEIGHT = 600, 680
BOARD_SIZE = 540
BOARD_LEFT = 30
BOARD_TOP = 110
CELL_SIZE = BOARD_SIZE // 3

BG = (18, 24, 33)
PANEL = (28, 36, 48)
GRID = (222, 232, 242)
GRID_SHADOW = (76, 93, 113)
TEXT = (244, 247, 251)
MUTED = (151, 164, 181)
ACCENT = (87, 209, 168)
PLAYER_COLOR = (255, 205, 92)
COMPUTER_COLOR = (102, 194, 255)
WIN_COLOR = (112, 245, 180)
BUTTON = (45, 58, 76)
BUTTON_HOVER = (59, 76, 99)


def _cell_rect(row, col):
    return pygame.Rect(
        BOARD_LEFT + col * CELL_SIZE,
        BOARD_TOP + row * CELL_SIZE,
        CELL_SIZE,
        CELL_SIZE,
    )


def _cell_from_pos(pos):
    x, y = pos
    if not (BOARD_LEFT <= x < BOARD_LEFT + BOARD_SIZE and BOARD_TOP <= y < BOARD_TOP + BOARD_SIZE):
        return None
    return ((y - BOARD_TOP) // CELL_SIZE, (x - BOARD_LEFT) // CELL_SIZE)


def _draw_text(screen, font, text, color, center):
    surface = font.render(text, True, color)
    rect = surface.get_rect(center=center)
    screen.blit(surface, rect)
    return rect


def _draw_x(screen, rect):
    padding = 42
    start_a = (rect.left + padding, rect.top + padding)
    end_a = (rect.right - padding, rect.bottom - padding)
    start_b = (rect.right - padding, rect.top + padding)
    end_b = (rect.left + padding, rect.bottom - padding)
    pygame.draw.line(screen, PLAYER_COLOR, start_a, end_a, 14)
    pygame.draw.line(screen, PLAYER_COLOR, start_b, end_b, 14)


def _draw_o(screen, rect):
    pygame.draw.circle(screen, COMPUTER_COLOR, rect.center, 58, 12)


def _draw_board(screen, frame, selected, win_line):
    board_rect = pygame.Rect(BOARD_LEFT, BOARD_TOP, BOARD_SIZE, BOARD_SIZE)
    pygame.draw.rect(screen, PANEL, board_rect, border_radius=8)

    for row in range(3):
        for col in range(3):
            rect = _cell_rect(row, col)
            if selected == (row, col):
                pygame.draw.rect(screen, (39, 51, 68), rect.inflate(-12, -12), border_radius=8)
            if win_line and (row, col) in win_line:
                pygame.draw.rect(screen, (35, 77, 61), rect.inflate(-12, -12), border_radius=8)

            if frame[row][col] == functions.PLAYER:
                _draw_x(screen, rect)
            elif frame[row][col] == functions.COMPUTER:
                _draw_o(screen, rect)

    for i in range(1, 3):
        offset = BOARD_LEFT + i * CELL_SIZE
        pygame.draw.line(screen, GRID_SHADOW, (offset + 3, BOARD_TOP + 18), (offset + 3, BOARD_TOP + BOARD_SIZE - 18), 8)
        pygame.draw.line(screen, GRID, (offset, BOARD_TOP + 18), (offset, BOARD_TOP + BOARD_SIZE - 18), 5)

        offset = BOARD_TOP + i * CELL_SIZE
        pygame.draw.line(screen, GRID_SHADOW, (BOARD_LEFT + 18, offset + 3), (BOARD_LEFT + BOARD_SIZE - 18, offset + 3), 8)
        pygame.draw.line(screen, GRID, (BOARD_LEFT + 18, offset), (BOARD_LEFT + BOARD_SIZE - 18, offset), 5)


def _draw_button(screen, font, rect, text):
    color = BUTTON_HOVER if rect.collidepoint(pygame.mouse.get_pos()) else BUTTON
    pygame.draw.rect(screen, color, rect, border_radius=7)
    _draw_text(screen, font, text, TEXT, rect.center)


def _make_computer_move(frame):
    move = functions.best_move(frame)
    if move is not None:
        row, col = move
        frame[row][col] = functions.COMPUTER


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tic-Tac-Toe")

    try:
        icon = pygame.image.load("tic-tac-toe.png")
        pygame.display.set_icon(icon)
    except pygame.error:
        pass

    title_font = pygame.font.SysFont("Segoe UI", 38, bold=True)
    status_font = pygame.font.SysFont("Segoe UI", 24, bold=True)
    body_font = pygame.font.SysFont("Segoe UI", 19)
    button_font = pygame.font.SysFont("Segoe UI", 18, bold=True)

    frame = functions.new_frame()
    selected = (1, 1)
    scores = {"player": 0, "computer": 0, "draw": 0}
    status = "Your turn"
    game_over = False
    win_line = None
    reset_button = pygame.Rect(418, 38, 142, 44)
    clock = pygame.time.Clock()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                row, col = selected
                if event.key in (pygame.K_r, pygame.K_SPACE):
                    frame = functions.new_frame()
                    selected = (1, 1)
                    status = "Your turn"
                    game_over = False
                    win_line = None
                elif event.key == pygame.K_UP:
                    selected = (max(0, row - 1), col)
                elif event.key == pygame.K_DOWN:
                    selected = (min(2, row + 1), col)
                elif event.key == pygame.K_LEFT:
                    selected = (row, max(0, col - 1))
                elif event.key == pygame.K_RIGHT:
                    selected = (row, min(2, col + 1))
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if not game_over and frame[row][col] == functions.EMPTY:
                        frame[row][col] = functions.PLAYER
                        status, game_over, win_line = _finish_turn(frame, scores)

            if event.type == pygame.MOUSEMOTION:
                hovered_cell = _cell_from_pos(event.pos)
                if hovered_cell is not None:
                    selected = hovered_cell

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if reset_button.collidepoint(event.pos):
                    frame = functions.new_frame()
                    selected = (1, 1)
                    status = "Your turn"
                    game_over = False
                    win_line = None
                    continue

                cell = _cell_from_pos(event.pos)
                if cell is not None:
                    selected = cell
                    row, col = cell
                    if not game_over and frame[row][col] == functions.EMPTY:
                        frame[row][col] = functions.PLAYER
                        status, game_over, win_line = _finish_turn(frame, scores)

        screen.fill(BG)
        _draw_text(screen, title_font, "Tic-Tac-Toe", TEXT, (145, 46))
        _draw_text(
            screen,
            body_font,
            f"You {scores['player']}   AI {scores['computer']}   Draws {scores['draw']}",
            MUTED,
            (204, 82),
        )
        _draw_button(screen, button_font, reset_button, "New Game")
        _draw_board(screen, frame, selected, win_line)

        footer_rect = pygame.Rect(30, 662 - 42, 540, 38)
        pygame.draw.rect(screen, PANEL, footer_rect, border_radius=7)
        color = WIN_COLOR if game_over else ACCENT
        _draw_text(screen, status_font, status, color, footer_rect.center)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()


def _finish_turn(frame, scores):
    if functions.win_check(frame, functions.PLAYER):
        scores["player"] += 1
        return "You win! Press R for another round", True, functions.winning_line(frame, functions.PLAYER)

    if functions.is_draw(frame):
        scores["draw"] += 1
        return "Draw! Press R to play again", True, None

    _make_computer_move(frame)

    if functions.win_check(frame, functions.COMPUTER):
        scores["computer"] += 1
        return "AI wins. Press R for a rematch", True, functions.winning_line(frame, functions.COMPUTER)

    if functions.is_draw(frame):
        scores["draw"] += 1
        return "Draw! Press R to play again", True, None

    return "Your turn", False, None
