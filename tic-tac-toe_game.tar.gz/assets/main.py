import asyncio

import pygame

import functions

WIDTH, HEIGHT = 600, 680
BOARD_SIZE = 540
BOARD_LEFT = 30
BOARD_TOP = 110
CELL_SIZE = BOARD_SIZE // 3

BG = (18, 24, 33)
PANEL = (28, 36, 48)
GRID = (222, 232, 242)
GRID_SHADOW = (76, 93, 113)
TEXT = (244, 247, 251)
MUTED = (151, 164, 181)
ACCENT = (87, 209, 168)
PLAYER_COLOR = (255, 205, 92)
COMPUTER_COLOR = (102, 194, 255)
WIN_COLOR = (112, 245, 180)
BUTTON = (45, 58, 76)
BUTTON_HOVER = (59, 76, 99)


def draw_text(screen, font, text, color, center):
    surface = font.render(text, True, color)
    rect = surface.get_rect(center=center)
    screen.blit(surface, rect)
    return rect


def load_image(path, size=None):
    try:
        image = pygame.image.load(path).convert_alpha()
        if size:
            image = pygame.transform.smoothscale(image, size)
        return image
    except pygame.error:
        return None


def cell_rect(row, col):
    return pygame.Rect(
        BOARD_LEFT + col * CELL_SIZE,
        BOARD_TOP + row * CELL_SIZE,
        CELL_SIZE,
        CELL_SIZE,
    )


def cell_from_pos(pos):
    x, y = pos
    if not (BOARD_LEFT <= x < BOARD_LEFT + BOARD_SIZE and BOARD_TOP <= y < BOARD_TOP + BOARD_SIZE):
        return None
    return ((y - BOARD_TOP) // CELL_SIZE, (x - BOARD_LEFT) // CELL_SIZE)


def draw_x(screen, rect):
    padding = 42
    pygame.draw.line(
        screen,
        PLAYER_COLOR,
        (rect.left + padding, rect.top + padding),
        (rect.right - padding, rect.bottom - padding),
        14,
    )
    pygame.draw.line(
        screen,
        PLAYER_COLOR,
        (rect.right - padding, rect.top + padding),
        (rect.left + padding, rect.bottom - padding),
        14,
    )


def draw_o(screen, rect):
    pygame.draw.circle(screen, COMPUTER_COLOR, rect.center, 58, 12)


def draw_button(screen, font, rect, text):
    color = BUTTON_HOVER if rect.collidepoint(pygame.mouse.get_pos()) else BUTTON
    pygame.draw.rect(screen, color, rect, border_radius=7)
    draw_text(screen, font, text, TEXT, rect.center)


def draw_board(screen, frame, selected, win_line):
    board_rect = pygame.Rect(BOARD_LEFT, BOARD_TOP, BOARD_SIZE, BOARD_SIZE)
    pygame.draw.rect(screen, PANEL, board_rect, border_radius=8)

    for row in range(3):
        for col in range(3):
            rect = cell_rect(row, col)
            if selected == (row, col):
                pygame.draw.rect(screen, (39, 51, 68), rect.inflate(-12, -12), border_radius=8)
            if win_line and (row, col) in win_line:
                pygame.draw.rect(screen, (35, 77, 61), rect.inflate(-12, -12), border_radius=8)

            if frame[row][col] == functions.PLAYER:
                draw_x(screen, rect)
            elif frame[row][col] == functions.COMPUTER:
                draw_o(screen, rect)

    for i in range(1, 3):
        x = BOARD_LEFT + i * CELL_SIZE
        pygame.draw.line(screen, GRID_SHADOW, (x + 3, BOARD_TOP + 18), (x + 3, BOARD_TOP + BOARD_SIZE - 18), 8)
        pygame.draw.line(screen, GRID, (x, BOARD_TOP + 18), (x, BOARD_TOP + BOARD_SIZE - 18), 5)

        y = BOARD_TOP + i * CELL_SIZE
        pygame.draw.line(screen, GRID_SHADOW, (BOARD_LEFT + 18, y + 3), (BOARD_LEFT + BOARD_SIZE - 18, y + 3), 8)
        pygame.draw.line(screen, GRID, (BOARD_LEFT + 18, y), (BOARD_LEFT + BOARD_SIZE - 18, y), 5)


def reset_round():
    return {
        "frame": functions.new_frame(),
        "selected": (1, 1),
        "status": "Your turn",
        "game_over": False,
        "win_line": None,
    }


def finish_turn(state, scores):
    frame = state["frame"]
    if functions.win_check(frame, functions.PLAYER):
        scores["player"] += 1
        state["status"] = "You win! Press R for another round"
        state["game_over"] = True
        state["win_line"] = functions.winning_line(frame, functions.PLAYER)
        return

    if functions.is_draw(frame):
        scores["draw"] += 1
        state["status"] = "Draw! Press R to play again"
        state["game_over"] = True
        return

    move = functions.best_move(frame)
    if move is not None:
        row, col = move
        frame[row][col] = functions.COMPUTER

    if functions.win_check(frame, functions.COMPUTER):
        scores["computer"] += 1
        state["status"] = "AI wins. Press R for a rematch"
        state["game_over"] = True
        state["win_line"] = functions.winning_line(frame, functions.COMPUTER)
    elif functions.is_draw(frame):
        scores["draw"] += 1
        state["status"] = "Draw! Press R to play again"
        state["game_over"] = True
    else:
        state["status"] = "Your turn"


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tic-Tac-Toe")

    icon = load_image("tic-tac-toe.png")
    if icon:
        pygame.display.set_icon(icon)

    title_font = pygame.font.SysFont("Segoe UI", 38, bold=True)
    start_title_font = pygame.font.SysFont("Segoe UI", 44, bold=True)
    status_font = pygame.font.SysFont("Segoe UI", 24, bold=True)
    body_font = pygame.font.SysFont("Segoe UI", 19)
    button_font = pygame.font.SysFont("Segoe UI", 18, bold=True)
    hint_font = pygame.font.SysFont("Segoe UI", 18)

    start_img = load_image("start-button.png", (190, 190))
    start_rect = pygame.Rect(205, 220, 190, 190)
    reset_button = pygame.Rect(418, 38, 142, 44)
    scores = {"player": 0, "computer": 0, "draw": 0}
    state = reset_round()
    mode = "start"
    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif mode == "start":
                if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    mode = "game"
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and start_rect.collidepoint(event.pos):
                    mode = "game"

            elif mode == "game":
                if event.type == pygame.KEYDOWN:
                    row, col = state["selected"]
                    if event.key in (pygame.K_r, pygame.K_SPACE):
                        state = reset_round()
                    elif event.key == pygame.K_UP:
                        state["selected"] = (max(0, row - 1), col)
                    elif event.key == pygame.K_DOWN:
                        state["selected"] = (min(2, row + 1), col)
                    elif event.key == pygame.K_LEFT:
                        state["selected"] = (row, max(0, col - 1))
                    elif event.key == pygame.K_RIGHT:
                        state["selected"] = (row, min(2, col + 1))
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        row, col = state["selected"]
                        if not state["game_over"] and state["frame"][row][col] == functions.EMPTY:
                            state["frame"][row][col] = functions.PLAYER
                            finish_turn(state, scores)

                elif event.type == pygame.MOUSEMOTION:
                    hovered_cell = cell_from_pos(event.pos)
                    if hovered_cell is not None:
                        state["selected"] = hovered_cell

                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if reset_button.collidepoint(event.pos):
                        state = reset_round()
                    else:
                        cell = cell_from_pos(event.pos)
                        if cell is not None:
                            state["selected"] = cell
                            row, col = cell
                            if not state["game_over"] and state["frame"][row][col] == functions.EMPTY:
                                state["frame"][row][col] = functions.PLAYER
                                finish_turn(state, scores)

        screen.fill(BG)

        if mode == "start":
            draw_text(screen, start_title_font, "Tic-Tac-Toe", TEXT, (WIDTH // 2, 116))
            draw_text(screen, body_font, "Play X against a smarter AI", MUTED, (WIDTH // 2, 162))
            if start_rect.collidepoint(pygame.mouse.get_pos()):
                pygame.draw.circle(screen, ACCENT, start_rect.center, 112, 3)
            if start_img:
                screen.blit(start_img, start_rect)
            else:
                draw_button(screen, button_font, start_rect, "Start")
            draw_text(screen, hint_font, "Click start, or press Enter", MUTED, (WIDTH // 2, 492))

        else:
            draw_text(screen, title_font, "Tic-Tac-Toe", TEXT, (145, 46))
            draw_text(
                screen,
                body_font,
                f"You {scores['player']}   AI {scores['computer']}   Draws {scores['draw']}",
                MUTED,
                (204, 82),
            )
            draw_button(screen, button_font, reset_button, "New Game")
            draw_board(screen, state["frame"], state["selected"], state["win_line"])

            footer_rect = pygame.Rect(30, 620, 540, 38)
            pygame.draw.rect(screen, PANEL, footer_rect, border_radius=7)
            color = WIN_COLOR if state["game_over"] else ACCENT
            draw_text(screen, status_font, state["status"], color, footer_rect.center)

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
