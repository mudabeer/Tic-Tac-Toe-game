import string

PLAYER = -1
COMPUTER = 1
EMPTY = 0

WIN_LINES = (
    ((0, 0), (0, 1), (0, 2)),
    ((1, 0), (1, 1), (1, 2)),
    ((2, 0), (2, 1), (2, 2)),
    ((0, 0), (1, 0), (2, 0)),
    ((0, 1), (1, 1), (2, 1)),
    ((0, 2), (1, 2), (2, 2)),
    ((0, 0), (1, 1), (2, 2)),
    ((0, 2), (1, 1), (2, 0)),
)


def special_c(text: str):
    new = text
    for char in text:
        if char in string.punctuation:
            new = new.replace(char, "")
    return new


def new_frame():
    return [[EMPTY for _ in range(3)] for _ in range(3)]


def map(frame: list[list[int]]):
    print("")
    for row in frame:
        print("\t", end="")
        for cell in row:
            if cell == PLAYER:
                print("x\t", end="")
            elif cell == EMPTY:
                print("-\t", end="")
            elif cell == COMPUTER:
                print("o\t", end="")
        print("\n")
    print("_" * 50)


def index(num):
    if num <= 3:
        return [0, num - 1]
    if num <= 6:
        return [1, num - 4]
    if num <= 9:
        return [2, num - 7]
    return [0, 0]


def available_moves(frame: list[list[int]]):
    return [
        (row, col)
        for row in range(3)
        for col in range(3)
        if frame[row][col] == EMPTY
    ]


def winning_line(frame: list[list[int]], key: int):
    for line in WIN_LINES:
        if all(frame[row][col] == key for row, col in line):
            return line
    return None


def win_check(frame: list[list[int]], key: int):
    return winning_line(frame, key) is not None


def is_draw(frame: list[list[int]]):
    return not available_moves(frame) and not win_check(frame, PLAYER) and not win_check(frame, COMPUTER)


def diagonal_check(frame: list[list[int]], key: int):
    countw_1 = 0
    countw_2 = 0
    for i in range(3):
        if frame[i][i] == key:
            countw_1 += 1
        if frame[i][2 - i] == key:
            countw_2 += 1
    return countw_1, countw_2


def VH_check(frame: list[list[int]], key: int, rang, cur):
    countr = 0
    countc = 0
    for j in range(3):
        if frame[cur][j] == key:
            countr += 1
        if frame[j][cur] == key:
            countc += 1

    if countr == rang or countc == rang:
        return countr, countc

    return 0, 0


def poss_match(frame: list[list[int]], key: int):
    for line in WIN_LINES:
        values = [frame[row][col] for row, col in line]
        if values.count(key) == 2 and values.count(EMPTY) == 1:
            empty_index = values.index(EMPTY)
            row, col = line[empty_index]
            return [row, col, True]
    return [0, 0, False]


def random(frame: list[list[int]]):
    moves = available_moves(frame)
    if moves:
        row, col = moves[0]
        return [row, col, True]
    return [0, 0, False]


def best_move(frame: list[list[int]]):
    if win_check(frame, COMPUTER) or win_check(frame, PLAYER):
        return None

    move = poss_match(frame, COMPUTER)
    if move[2]:
        return (move[0], move[1])

    move = poss_match(frame, PLAYER)
    if move[2]:
        return (move[0], move[1])

    if frame[1][1] == EMPTY:
        return (1, 1)

    for row, col in ((0, 0), (0, 2), (2, 0), (2, 2)):
        if frame[row][col] == EMPTY:
            return (row, col)

    moves = available_moves(frame)
    return moves[0] if moves else None
